void caesarEncode(char plaintext[], int key);
void caesarDecode(char ciphertext[], int key);