#include <stdio.h>
#include <string.h>

typedef struct {int id; char *name;} process_t;
typedef struct {void * data;} queue_t;

void enqueue(queue_t *queue, void *element)
{
} 

void dequeue(queue_t *queue) 
{
} 

int main()
{
    return 0;
}